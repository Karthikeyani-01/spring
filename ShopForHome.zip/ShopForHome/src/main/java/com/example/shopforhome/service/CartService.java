package com.example.shopforhome.service;

import java.util.Collection;

import com.example.shopforhome.model.Cart;
import com.example.shopforhome.model.ProductInOrder;
import com.example.shopforhome.model.User;


public interface CartService {
    Cart getCart(User user);

    void mergeLocalCart(Collection<ProductInOrder> productInOrders, User user);

    void delete(String itemId, User user);

    void checkout(User user);
}
