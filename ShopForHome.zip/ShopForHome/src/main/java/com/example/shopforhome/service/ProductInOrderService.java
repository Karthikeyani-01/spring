package com.example.shopforhome.service;

import com.example.shopforhome.model.ProductInOrder;
import com.example.shopforhome.model.User;

public interface ProductInOrderService {
    void update(String itemId, Integer quantity, User user);
    ProductInOrder findOne(String itemId, User user);
}
