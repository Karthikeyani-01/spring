package com.example.shopforhome.enums;


public interface CodeEnum {
    Integer getCode();

}
